import React from 'react'
// import {AvatarSelector} from '../../component/avatar'


export default class UserInfo extends React.Component{
    constructor(){
        super();
        this.state={

        }
    }
    render(){
        return(
            <div>
                <h2>UserInfo</h2>
                {/*<AvatarSelector></AvatarSelector>*/}
            </div>
        )
    }
}